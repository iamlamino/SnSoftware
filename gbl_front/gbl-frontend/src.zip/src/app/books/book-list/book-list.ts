import { Component } from '@angular/core';

@Component({
  selector: 'app-books-list',
  imports: [],
  templateUrl: './book-list.html',
  styleUrl: './book-list.css',
})
export class BooksList {}
