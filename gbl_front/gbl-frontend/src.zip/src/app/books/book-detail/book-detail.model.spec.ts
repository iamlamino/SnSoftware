import { BookDetail } from './book-detailmodel';

describe('BookDetail', () => {
  it('should create an instance', () => {
    expect(new BookDetail()).toBeTruthy();
  });
});
