import { Component } from '@angular/core';

@Component({
  selector: 'app-book-form',
  imports: [],
  templateUrl: './book-form.html',
  styleUrl: './book-form.css'
})
export class BookForm {

}
