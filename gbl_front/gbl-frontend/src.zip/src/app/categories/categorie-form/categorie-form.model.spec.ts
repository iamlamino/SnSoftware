import { CategorieForm } from './categorie-formmodel';

describe('CategorieForm', () => {
  it('should create an instance', () => {
    expect(new CategorieForm()).toBeTruthy();
  });
});
