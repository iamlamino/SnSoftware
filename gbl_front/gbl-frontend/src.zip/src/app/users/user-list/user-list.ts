import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Utilisateur, UtilisateurType } from '../../services/utilisateur';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './user-list.html',
})
export class UserList implements OnInit {
  utilisateurs: UtilisateurType[] = [];

  constructor(private utilisateur: Utilisateur) {}

  ngOnInit(): void {
    this.utilisateur.getAll().subscribe((data) => {
      this.utilisateurs = data;
    });
  }

  supprimer(id: number): void {
    this.utilisateur.delete(id).subscribe(() => {
      this.utilisateurs = this.utilisateurs.filter((u) => u.id !== id);
    });
  }
}
