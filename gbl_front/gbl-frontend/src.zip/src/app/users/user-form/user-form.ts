import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';
import { Utilisateur, UtilisateurType } from '../../services/utilisateur';

@Component({
  selector: 'app-user-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './user-form.html',
})
export class UserForm implements OnInit {
  form!: FormGroup;
  id?: number;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private utilisateur: Utilisateur
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      nom: ['', Validators.required],
      prenom: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      motDePasse: ['', Validators.required],
      statut: ['USER', Validators.required],
    });

    this.id = Number(this.route.snapshot.paramMap.get('id'));
    if (this.id) {
      this.utilisateur.getById(this.id).subscribe((user) => {
        this.form.patchValue(user);
      });
    }
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    const user: UtilisateurType = this.form.value;

    const request = this.id
      ? this.utilisateur.update(this.id, user)
      : this.utilisateur.create(user);

    request.subscribe(() => {
      this.router.navigate(['/users']);
    });
  }
}
